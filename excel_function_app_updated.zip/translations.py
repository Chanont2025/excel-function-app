translations = {
    'en': {
        'title': "📊 Excel Function Explorer",
        'upload_csv': "📥 Upload a CSV file with function data",
        'search_label': "🔍 Search for an Excel Function",
        'no_result': "No results found",
    },
    'th': {
        'title': "📊 แอปสำรวจสูตร Excel",
        'upload_csv': "📥 อัปโหลดไฟล์ CSV ที่มีข้อมูลสูตร Excel",
        'search_label': "🔍 ค้นหาสูตร Excel",
        'no_result': "ไม่พบผลลัพธ์",
    }
}