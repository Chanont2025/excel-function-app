# 📊 Excel Function Explorer

A bilingual (TH/EN) **Streamlit web app** that helps users **search, explore, and learn Excel functions** interactively — with examples, categories, real-time autocomplete, and CSV upload support.

... (ข้อความ README เต็มที่สร้างไว้ก่อนหน้านี้)